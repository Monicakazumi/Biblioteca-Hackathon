<script>alert("Usuário inválido!")</script>

<script>location.href='login.php'</script>

