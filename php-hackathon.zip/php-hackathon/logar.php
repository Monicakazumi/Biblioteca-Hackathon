<?php

if (isset($_POST['ra']) && !empty($_POST['ra']) && isset($_POST['senha']) && !empty($_POST['senha'])) {
    require 'conexao.php';
    require 'Usuario.class.php'; //chamando a classe criada

    //instanciando o objeto
    $u = new Usuario();

    //escapa de caracteres especiais, aumentando a segurança
    $ra = addslashes($_POST['ra']);
    $senha   = addslashes($_POST['senha']);
    
    if ($u->login($ra, $senha) == true) {
        if (isset($_SESSION['idUser'])) {
            header("Location: index.php");
            exit;
        }
        header("Location: erro.php");
    }
}
header("Location: erro.php");
