package com.unialfa.biblioteca.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Autor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_autor")
    private Long id;
    private String nome;
    private String endereco;
    private String cidade;
    private String uf;
    private Integer telefone;

    @Override
    public String toString() {
        return id +"-"+ nome;
    }
}