package com.unialfa.biblioteca.service;

import com.unialfa.biblioteca.model.Categoria;
import com.unialfa.biblioteca.repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoriaService {

    @Autowired
    private CategoriaRepository repository;

    public Categoria salvarCategoria(Categoria categoria){
        return repository.save(categoria);
    }

    public List<Categoria> listarCategoria(){
        return repository.findAll();
    }

    public Categoria buscarPorId(Long id) {
        return repository.findById(id).get();
    }

    public void removerPorId(Long id) {
        try {
            repository.deleteById(id);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

}
