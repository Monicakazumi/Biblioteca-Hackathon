package com.unialfa.biblioteca.controller;


import com.unialfa.biblioteca.model.Categoria;
import com.unialfa.biblioteca.service.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("categoria")
public class CategoriaController {

    @Autowired
    private CategoriaService serviceCategoria;

    @GetMapping("lista")
    public String iniciarLista(Model model){
        model.addAttribute("listaCategorias",
                "Lista de Categorias");
        model.addAttribute("listaDeCategorias",
                serviceCategoria.listarCategoria());
        return "/categoria/lista";
    }

    @GetMapping("formulario")
    public String iniciarFormulario(Model model, Categoria categoria){
        model.addAttribute("listaCategorias",
                "Cadastro de Categorias");
        return "/categoria/formulario";
    }

    @PostMapping("salvar")
    public String salvar(Categoria categoria){
        serviceCategoria.salvarCategoria(categoria);
        return "redirect:/categoria/lista";
    }

    @GetMapping("alterar/{id}")
    public String alterar(@PathVariable Long id, Model model){
        model.addAttribute("listaCategorias",
                "Cadastro de Categorias");
        model.addAttribute("categoria",
                serviceCategoria.buscarPorId(id));
        return "/categoria/formulario";
    }

    @GetMapping("remover/{id}")
    public String remover(@PathVariable Long id){
        serviceCategoria.removerPorId(id);
        return "redirect:/categoria/lista";
    }
}
