package com.unialfa.biblioteca.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Livro{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    @Column(name = "id_livro")
    private Long id;
    private String titulo;
    private String subTitulo;
    private String isbn;
    @ManyToOne
    @JoinColumn(name = "id_autor")
    private Autor autor;
    @ManyToOne
    @JoinColumn(name = "id_editora")
    private Editora editora;
    @ManyToOne
    @JoinColumn(name = "id_categoria")
    private Categoria categoria;
    private String local;
    private Integer ano;

    @Override
    public String toString() {
        return id +"-"+ titulo;
    }
}
